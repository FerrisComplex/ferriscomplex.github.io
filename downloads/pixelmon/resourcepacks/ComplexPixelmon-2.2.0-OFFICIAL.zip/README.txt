*Project-Revive*

Welcome to Project Revive! This is a Pixelmon Reforged GUI & Icon Texture/Resource pack.
This pack is a work of passion between myself(Doublebass91) and my Wife AutumnAsylum.
This pack includes a full GUI reskin and icon replacement, as well as some music for fun.

Why is it called Revive? This pack was based from an old texture pack from MC-1.6.4 named Project Pokemon.
the pack seemed to have died and development was stopped at MC-1.8. As soon as we saw the style in which the pack 
was, we knew that we needed to "Revive" this aesthetic. Nearly All works in this pack have been reformatted, retextured
and/or replaced from that original work.

This pack also includes "Pixelmon's Faithful x32 addon" By EddyHG80. FULL CREDIT FOR ICONS GO TO HIM 
Original Link to his addon " https://www.curseforge.com/minecraft/texture-packs/pixelmons-faithful-x32-addon "

IMPORTANT- Any and All music/sound files belong to Nintendo ALL RIGHTS RESERVED!

This pack Was also developed in mind to be used exclusively By the Complex Pixelmon & PokeRivals Modpack.

If you are using this pack on another server please recognize that, that server does NOT have permission to
use this pack, as such we appreciate you liking it however dont do that.


We hope this makes your pixelmon experience just that much better.
We will be updating and adding to the pack moving forward so look out for that.


Thank you.

-----------------------------------------------------------------------------------------------------------------------

Unfortunately, after Doublebass91 and AutumnAsylum have become difficult to contact, and I (Dragonmatt99), have
continued to update this texture pack as content for the Pixelmon Reforged mod further develops.  I have begun my
involvement at the start of version 8.1.0, every retexture prior to this version is to have full credit to the original
two artists who started this project.  All above information is still applicable and to be noted.